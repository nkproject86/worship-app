// ================================================================
//  LANGKAH SETUP FIREBASE:
//
//  1. Buka https://console.firebase.google.com
//  2. Klik "Add project" → beri nama "worship-app"
//  3. Setelah project dibuat, klik ikon "</>" (Web app)
//  4. Register app dengan nama "worship-app"
//  5. Copy nilai firebaseConfig di bawah ini dan paste ke sini
//  6. Di Firebase Console → klik "Firestore Database"
//     → "Create database" → pilih "Start in test mode" → Next → Enable
// ================================================================

import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey:            "GANTI_DENGAN_API_KEY_KAMU",
  authDomain:        "GANTI_DENGAN_AUTH_DOMAIN_KAMU",
  projectId:         "GANTI_DENGAN_PROJECT_ID_KAMU",
  storageBucket:     "GANTI_DENGAN_STORAGE_BUCKET_KAMU",
  messagingSenderId: "GANTI_DENGAN_MESSAGING_SENDER_ID_KAMU",
  appId:             "GANTI_DENGAN_APP_ID_KAMU"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
